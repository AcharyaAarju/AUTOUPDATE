# Dell BIOS自動更新無効化手順書

## 📋 概要

この手順書は、Windows 10のBIOSで自動更新とスリープ機能を無効化し、24/7サーバー運用に最適化する設定方法を説明します。

---

## 🚀 BIOS設定画面への入り方

### **ステップ1: PCを再起動**
1. **スタートメニュー** → **電源** → **再起動** をクリック
2. または既に電源が切れている場合は電源ボタンを押す

### **ステップ2: BIOS画面に入る**
1. **DELLロゴまたはロゴマークが表示されたらすぐに**
2. **F2キーを連続で押す**
3. **BIOS設定画面**が開くまで続ける

#### 💡 コツ
- ロゴが見えたら**すぐにF2を連打**
- 押すタイミングが遅いとWindowsが起動してしまいます
- 失敗した場合は再起動して再度挑戦

---

## ⚙️ BIOS設定変更手順

**⚠️ 重要:** マウス右クリックなどは使えませんので、選択の際はエンターキーを使用

### **設定1: Secure Boot の無効化**

**目的:** セキュアブートを無効にして互換性を向上

1. **「Settings」** (設定) タブに移動
2. **「Secure Boot」** を選択
3. **「+」キー** または **Enter** を押して展開
4. **「Secure Boot Enable」** に移動
5. **スペースキー** または **Enter** を押してチェックを外す 
6.✅チェックが外されていることを確認
7. **「Apply」** を押す

```
ナビゲーション: Settings → Secure Boot → Secure Boot Enable
変更内容: [✓] Enabled → [ ] Enabled → Apply
```

---

### **設定2: Deep Sleep Control の無効化**

**目的:** 深いスリープ状態を無効にして24/7稼働を保証

1. **「Power Management」** タブに移動
2. **「Power Management」** の **「+」** を選択
3. **「Deep Sleep Control」** を探す
4. **Enter** を押して設定を変更
5. **「Enabled」** → **「Disabled」** に変更
6. **「Apply」** を押す

```
ナビゲーション: Settings → Power Management → Deep Sleep Control
変更内容: Enabled → Disabled → Apply
```

---

### **設定3: Block Sleep の無効化**

**目的:** スリープブロック機能を無効にして確実にスリープを防止

1. **Power Management** セクション内で
2. **「Block Sleep」** を探す
3. **Enter** を押して設定を変更
4. **「Enabled」** → **「Disabled」** に変更
5. **「Apply」** を押す

```
ナビゲーション: Settings → Power Management → Block Sleep
変更内容: Enabled → Disabled → Apply
```

---

## 💾 設定完了と終了

1. **すべての変更が正しく適用されたか確認**
2. **「Exit」** キーを押す
3. **「Save Changes and Exit」** を選択
4. **「Yes」** を選択してシステム再起動

---

## ✅ 設定完了後の確認

Windows起動後、PowerShellで確認：

```powershell
# Secure Boot状態確認
Confirm-SecureBootUEFI

# スリープ設定確認
powercfg /availablesleepstates
```

**期待される結果:**
- Secure Boot: False (無効)
- スタンバイ (S3): 利用できません